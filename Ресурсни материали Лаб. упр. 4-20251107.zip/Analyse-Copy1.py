#!/usr/bin/env python
# coding: utf-8

#                                Хистограмен анализ и преобразуване на цифрови сигнали

# Задача 1: Заредете файл "my_voice_data.mp3" и визуализирайте съдържанието му.

# In[7]:


# pip install PyDub


# In[8]:


# conda install -c anaconda ffmpeg


# In[1]:


from pydub import AudioSegment
import matplotlib.pyplot as plt
import numpy as np


# In[2]:


# Заредете аудиофайла (.mp3)
audio       = AudioSegment.from_mp3(r'C:\Users\nicol\surename_name\my_voice_data.mp3')


# In[3]:


# За по-лесна обработка, преобразувайте в масив от числа
samples     = np.array(audio.get_array_of_samples())

# Извлечете честотата на дискретизация и броя на каналите
sample_rate = audio.frame_rate
channels    = audio.channels

#print(sample_rate, channels)

# Колко канала има в аудио файлът?


# In[4]:


# Разделете каналите
left_channel  = samples[::2]  # Ляв канал
right_channel = samples[1::2]  # Десен канал

# Създайте времеви масив
time          = np.linspace(0, len(left_channel) / sample_rate, len(left_channel))

# Визуализирайте двата канала. По абцисата да е представено времето [s], а по ордината амплитудата.


# In[ ]:





# In[ ]:





# In[5]:


# Проверете дължината на аудиозаписа и коригирайте спрямо броят на каналите
duration = len(samples) / float(sample_rate)

# Създайте времеви масив за визуализация
time     = np.linspace(0, duration, len(samples))

# Визуализирайте. По абцисата да е представено времето [s], а по ордината амплитудата.
# ...


# In[6]:


# Проверете дължината на аудиозаписа и коригирайте спрямо броят на каналите
duration = len(samples) / (float(sample_rate) * channels)

# Create a time array for visualization
time = np.linspace(0, duration, len(samples))

# Plot the audio waveform
plt.figure(figsize=(20, 8))
plt.title("Визуализация на съдържанието на файл: my_voice_data.mp3")
plt.xlabel("Продължителност (s)")
plt.ylabel("Амплитуда")
plt.plot(time, samples)
plt.show()


# In[7]:


# Създайте хистограма на сигнала
plt.figure(figsize=(20, 8))
plt.title("Хистограма на сигнала")
plt.xlabel("Стойности на сигнала")
plt.ylabel("Брой срещания")
plt.hist(samples, bins=1000, color='b', alpha=0.5)

# Покажете хистограмата
plt.show()


# In[8]:


# Извършете бързо преобразуване на Фурие (FFT) за левия канал
left_channel_fft  = np.fft.fft(left_channel)
left_channel_fft  = left_channel_fft[:len(left_channel_fft) // 2]  # Използваме само половината от резултата

# Извършете бързо преобразуване на Фурие (FFT) за десния канал
right_channel_fft = np.fft.fft(right_channel)
right_channel_fft = right_channel_fft[:len(right_channel_fft) // 2]  # Използваме само половината от резултата

# Създайте масив от честоти, съответстващи на FFT резултата
frequencies       = np.fft.fftfreq(len(left_channel), 1 / sample_rate)
frequencies       = frequencies[:len(frequencies) // 2]  # Използваме само половината от резултата

# Създайте графика за визуализация на честотния спектър на двата канала
# ...


# In[ ]:





# In[9]:


# Намерете минималната и максималната стойност на сигнала за целия период на записа
Xmin   = np.min(samples)
Xmax   = np.max(samples)

# Нормирайте стойностите в диапазона [0, 255]
X_norm = ((samples - Xmin) / (Xmax - Xmin) * 255).astype(np.uint8)

# Визуализирайте нормирания сигнал. По абцисата е да продължителността на записа [s], а по отдината - амплитудата. 
# ...


# In[ ]:





# In[10]:


# Визуализирайте хистограмата на нормализирания сигнал
plt.figure(figsize=(20, 8))
plt.title("Хистограма на нормализирания сигнал")
plt.xlabel("Квантуване")
plt.ylabel("Брой повторения")
plt.hist(X_norm, bins=256, range=(0, 255), color='b', alpha=0.5)
plt.show()


# In[11]:


# Извършете Фурие преобразуване
fft_result  = np.fft.fft(samples)

# Намерете честотните компоненти и амплитуди
frequencies = np.fft.fftfreq(len(samples), 1.0 / sample_rate)
amplitudes  = np.abs(fft_result)

# Визуализирайте спектъра
plt.figure(figsize=(20, 8))
plt.title("Спектър на аудио сигнала")
plt.xlabel("Честота (Hz)")
plt.ylabel("Амплитуда")
plt.xlim(0, sample_rate // 2)  # Ограничете до половината от отчетите (Nyquist)
plt.plot(frequencies[:len(frequencies)//2], amplitudes[:len(amplitudes)//2])
plt.show()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




